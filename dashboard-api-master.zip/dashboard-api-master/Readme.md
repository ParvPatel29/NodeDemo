Command to generate table from GUI to code
``sequelize-auto -o "./src/db/model" -d katon_dev -h localhost -u postgres -p 5432 -x thinkit -e postgres -l ts``
