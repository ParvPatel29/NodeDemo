import { body } from 'express-validator'

export const createStudenRemark = []

export const updateStudentRemark = []
