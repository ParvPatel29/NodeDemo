export const basicAuthOfEnableX: any = {
  auth: {
    username: process.env.ENABLEXAPPID,
    password: process.env.ENABLEXAPPKEY,
  },
}
