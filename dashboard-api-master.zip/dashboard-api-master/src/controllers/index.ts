// AdminController
export * as adminController from './admin'

// SchoolController
export * as schoolController from './school'

// // GESController
export * as gesController from './GES'
