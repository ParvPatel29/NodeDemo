// Auth Controller
export * as authController from './auth.controller'

// Area Controller
export * as areaController from './area.controller'

// School Controller
export * as schoolController from './school.controller'

// Teacher Controller
export * as teacherController from './teacher.controller'

// Student Controller
export * as studentController from './student.controller'

// Count Controller
export * as countController from './GES.controller'
